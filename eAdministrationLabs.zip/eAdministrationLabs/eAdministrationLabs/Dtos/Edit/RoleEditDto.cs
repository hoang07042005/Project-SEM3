﻿namespace eAdministrationLabs.Dtos.Edit
{
    public class RoleEditDto
    {
        public int Id { get; set; }
        public string RoleName { get; set; } = null!;
    }
}
