﻿namespace eAdministrationLabs.Dtos.Edit
{
    public class UserRoleEditDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int RoleId { get; set; }
    }
}
