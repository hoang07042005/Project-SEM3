﻿namespace eAdministrationLabs.Dtos.Create
{
    public class RoleCreateDto
    {
        public string RoleName { get; set; } = null!;
    }
}
