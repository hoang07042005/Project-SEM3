﻿namespace eAdministrationLabs.Dtos.Create
{
    public class NotificationCreateDto
    {
        public int? UserId { get; set; }
        public string Message { get; set; } = null!;

    }
}
